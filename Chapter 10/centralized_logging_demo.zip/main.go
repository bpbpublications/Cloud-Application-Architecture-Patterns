package main

import (
    "log"
    "time"
)

func main() {
    for {
        log.Println(`{"level":"INFO","timestamp":"` + time.Now().Format(time.RFC3339) + `","message":"Package shipped","order_id":12345}`)
        time.Sleep(5 * time.Second)
    }
}
