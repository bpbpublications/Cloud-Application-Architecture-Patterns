package models

type Product struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Price float64 `json:"price"`
}

var products = []Product{
	{ID: 1, Name: "Book", Price: 9.99},
	{ID: 2, Name: "Pen", Price: 1.50},
}

func GetProductByID(id int) *Product {
	for _, p := range products {
		if p.ID == id {
			return &p
		}
	}
	return nil
}