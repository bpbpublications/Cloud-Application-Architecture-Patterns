package handlers

import (
	"encoding/json"
	"net/http"
	"product-service/models"
	"github.com/gorilla/mux"
	"strconv"
)

func GetProduct(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	id, err := strconv.Atoi(vars["id"])
	if err != nil {
		http.Error(w, "Invalid product ID", http.StatusBadRequest)
		return
	}

	product := models.GetProductByID(id)
	if product == nil {
		http.NotFound(w, r)
		return
	}

	json.NewEncoder(w).Encode(product)
}